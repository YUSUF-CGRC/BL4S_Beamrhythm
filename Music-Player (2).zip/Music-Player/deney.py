def esregressor(target_variable):
    import numpy as np
    import pandas as pd
    from sklearn.preprocessing import PolynomialFeatures
    from sklearn.linear_model import LinearRegression

    # Verileri tanımlama
    data1 = {
        "e+B": [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.50],
        "P+B": [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.50],
        "P+S": [6750, 21500, 67500, 100000, 225000, 260000, 275000, 290000, 300000, 500000],
        "pi+B": [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.50],
        "pi+S": [10000, 67000, 100000, 22500, 225000, 280000, 280000, 270000, 270000, 260000],
        "K+B": [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.50],
        "K+S": [1000, 120000, 225000, 22500, 22500, 250000, 260000, 265000, 265000, 260000]
    }

    df1 = pd.DataFrame(data1)

    data2 = {
        target_variable: [22500, 4500, 22300, 22000, 10000, 9000, 8000, 6750, 5000, 3000],
    }

    df2 = pd.DataFrame(data2)

    # Bağımsız değişkenler ve bağımlı değişken
    X = df1.values
    y = df2.values

    # Polinom özelliklerini oluşturma
    poly_features = PolynomialFeatures(degree=2)
    X_poly = poly_features.fit_transform(X)

    # Polinom regresyon modelini oluşturma ve eğitme
    model = LinearRegression()
    model.fit(X_poly, y)

    # Kullanıcıdan yeni bağımsız değişkenleri al
    print("Lütfen parametreleri girin:")
    new_variables = []
    for col in df1.columns:
        value = float(input(f"{col}: "))
        new_variables.append(value)
    X_new = np.array(new_variables).reshape(1, -1)

    # Yeni bağımsız değişkenlerle tahmin yapma
    X_new_poly = poly_features.transform(X_new)
    y_new_pred = model.predict(X_new_poly)

    # Tahmin edilen y değerlerini ve yeni bağımsız değişkenleri birleştirme
    df_new_data = pd.DataFrame(X_new, columns=df1.columns)
    df_new_results = pd.DataFrame({target_variable: y_new_pred.flatten()})
    df_combined_results = pd.concat([df_new_data, df_new_results], axis=1)

    # Sonuçları yazdırma
    return df_combined_results

def psregressor(target_variable):
    import numpy as np
    import pandas as pd
    from sklearn.preprocessing import PolynomialFeatures
    from sklearn.linear_model import LinearRegression

    # Verileri tanımlama
    data1 = {
        "e+B": [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.50],
        "e+S": [22500, 4500, 22300, 22000, 10000, 9000, 8000, 6750, 5000, 3000],
        "P+B": [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.50],
        "pi+B": [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.50],
        "pi+S": [10000, 67000, 100000, 22500, 225000, 280000, 280000, 270000, 270000, 260000],
        "K+B": [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.50],
        "K+S": [1000, 120000, 225000, 22500, 22500, 250000, 260000, 265000, 265000, 260000]
    }

    df1 = pd.DataFrame(data1)

    data2 = {
        target_variable: [6750, 21500, 67500, 100000, 225000, 260000, 275000, 290000, 300000, 500000],
    }

    df2 = pd.DataFrame(data2)

    # Bağımsız değişkenler ve bağımlı değişken
    X = df1.values
    y = df2.values

    # Polinom özelliklerini oluşturma
    poly_features = PolynomialFeatures(degree=2)
    X_poly = poly_features.fit_transform(X)

    # Polinom regresyon modelini oluşturma ve eğitme
    model = LinearRegression()
    model.fit(X_poly, y)

    # Kullanıcıdan yeni bağımsız değişkenleri al
    print("Lütfen parametreleri girin:")
    new_variables = []
    for col in df1.columns:
        value = float(input(f"{col}: "))
        new_variables.append(value)
    X_new = np.array(new_variables).reshape(1, -1)

    # Yeni bağımsız değişkenlerle tahmin yapma
    X_new_poly = poly_features.transform(X_new)
    y_new_pred = model.predict(X_new_poly)

    # Tahmin edilen y değerlerini ve yeni bağımsız değişkenleri birleştirme
    df_new_data = pd.DataFrame(X_new, columns=df1.columns)
    df_new_results = pd.DataFrame({target_variable: y_new_pred.flatten()})
    df_combined_results = pd.concat([df_new_data, df_new_results], axis=1)

    # Sonuçları yazdırma
    return df_combined_results

def pisregressor(target_variable):
    import numpy as np
    import pandas as pd
    from sklearn.preprocessing import PolynomialFeatures
    from sklearn.linear_model import LinearRegression

    # Verileri tanımlama
    data1 = {
        "e+B": [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.50],
        "e+S": [22500, 4500, 22300, 22000, 10000, 9000, 8000, 6750, 5000, 3000],
        "P+B": [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.50],
        "P+S": [6750, 21500, 67500, 100000, 225000, 260000, 275000, 290000, 300000, 500000],
        "pi+B": [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.50],
        "K+B": [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.50],
        "K+S": [1000, 120000, 225000, 22500, 22500, 250000, 260000, 265000, 265000, 260000]
    }

    df1 = pd.DataFrame(data1)

    data2 = {
       target_variable: [10000, 67000, 100000, 22500, 225000, 280000, 280000, 270000, 270000, 260000],
    }

    df2 = pd.DataFrame(data2)

    # Bağımsız değişkenler ve bağımlı değişken
    X = df1.values
    y = df2.values

    # Polinom özelliklerini oluşturma
    poly_features = PolynomialFeatures(degree=2)
    X_poly = poly_features.fit_transform(X)

    # Polinom regresyon modelini oluşturma ve eğitme
    model = LinearRegression()
    model.fit(X_poly, y)

    # Kullanıcıdan yeni bağımsız değişkenleri al
    print("Lütfen parametreleri girin:")
    new_variables = []
    for col in df1.columns:
        value = float(input(f"{col}: "))
        new_variables.append(value)
    X_new = np.array(new_variables).reshape(1, -1)

    # Yeni bağımsız değişkenlerle tahmin yapma
    X_new_poly = poly_features.transform(X_new)
    y_new_pred = model.predict(X_new_poly)

    # Tahmin edilen y değerlerini ve yeni bağımsız değişkenleri birleştirme
    df_new_data = pd.DataFrame(X_new, columns=df1.columns)
    df_new_results = pd.DataFrame({target_variable: y_new_pred.flatten()})
    df_combined_results = pd.concat([df_new_data, df_new_results], axis=1)

    # Sonuçları yazdırma
    return df_combined_results

def ksregressor(target_variable):
    import numpy as np
    import pandas as pd
    from sklearn.preprocessing import PolynomialFeatures
    from sklearn.linear_model import LinearRegression

    # Verileri tanımlama
    data1 = {
        "e+B": [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.50],
        "e+S": [22500, 4500, 22300, 22000, 10000, 9000, 8000, 6750, 5000, 3000],
        "P+B": [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.50],
        "P+S": [6750, 21500, 67500, 100000, 225000, 260000, 275000, 290000, 300000, 500000],
        "pi+B": [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.50],
        "pi+S": [10000, 67000, 100000, 22500, 225000, 280000, 280000, 270000, 270000, 260000],
        "K+B": [0.45, 1.00, 2.00, 3.00, 4.00, 5.00, 6.00, 7.00, 8.00, 9.50],
    }

    df1 = pd.DataFrame(data1)

    data2 = {
       target_variable: [1000, 120000, 225000, 22500, 22500, 250000, 260000, 265000, 265000, 260000],
    }

    df2 = pd.DataFrame(data2)

    # Bağımsız değişkenler ve bağımlı değişken
    X = df1.values
    y = df2.values

    # Polinom özelliklerini oluşturma
    poly_features = PolynomialFeatures(degree=2)
    X_poly = poly_features.fit_transform(X)

    # Polinom regresyon modelini oluşturma ve eğitme
    model = LinearRegression()
    model.fit(X_poly, y)

    # Kullanıcıdan yeni bağımsız değişkenleri al
    print("Lütfen parametreleri girin:")
    new_variables = []
    for col in df1.columns:
        value = float(input(f"{col}: "))
        new_variables.append(value)
    X_new = np.array(new_variables).reshape(1, -1)

    # Yeni bağımsız değişkenlerle tahmin yapma
    X_new_poly = poly_features.transform(X_new)
    y_new_pred = model.predict(X_new_poly)

    # Tahmin edilen y değerlerini ve yeni bağımsız değişkenleri birleştirme
    df_new_data = pd.DataFrame(X_new, columns=df1.columns)
    df_new_results = pd.DataFrame({target_variable: y_new_pred.flatten()})
    df_combined_results = pd.concat([df_new_data, df_new_results], axis=1)

    # Sonuçları yazdırma
    return df_combined_results

print("Hangi değeri tahmin etmek istiyorsunuz? (e+S, P+S, pi+S, K+S)")
target_variable = input("Değer adı: ")

if target_variable == "e+S":
    print(esregressor(target_variable))
elif target_variable == "P+S":
    print(psregressor(target_variable))
elif target_variable == "pi+S":
    print(pisregressor(target_variable))
elif target_variable == "K+S":
    print(ksregressor(target_variable))
else:
    print("Geçersiz değer adı girdiniz.")
